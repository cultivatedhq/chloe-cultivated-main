import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    console.log('🧪 Generating test PDF report...')

    // Create sample survey data for testing
    const testSurveyData = {
      survey: {
        id: 'test-survey-123',
        title: 'Leadership Clarity Audit - Test Report',
        manager_name: 'Chloe James',
        manager_email: 'chloe@cultivatedhq.com.au',
        created_at: '2024-12-20T00:00:00Z',
        expires_at: '2024-12-23T00:00:00Z',
        description: 'This is a test report to demonstrate the automated PDF generation system.',
        scale_max: 5,
      },
      analytics: {
        total_responses: 1,
        overall_average: 4.2,
        overall_percentage: 84,
        strongest_area: "Leadership Alignment",
        strongest_score: 4.6,
        weakest_area: "Team Performance",
        weakest_score: 3.8,
        comments: [
          "This is a test comment to demonstrate the PDF generation system.",
          "Another sample comment to show how multiple comments appear in the report."
        ],
        comment_count: 2,
        performance_category: 'excellent'
      },
      processed_at: new Date().toISOString()
    }

    // Generate the HTML report
    const htmlReport = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Leadership Clarity Audit Report</title>
  <style>
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      margin: 40px;
      color: #333;
      line-height: 1.6;
      background-color: #ffffff;
    }

    h1, h2, h3 {
      color: #2A9D8F;
      margin-top: 0;
    }

    .header {
      text-align: center;
      border-bottom: 3px solid #2A9D8F;
      padding-bottom: 20px;
      margin-bottom: 40px;
    }

    .header h1 {
      font-size: 2.5em;
      margin-bottom: 10px;
      font-weight: 700;
    }

    .section {
      margin-bottom: 50px;
      page-break-inside: avoid;
    }

    .section h2 {
      font-size: 1.8em;
      margin-bottom: 20px;
      border-left: 4px solid #2A9D8F;
      padding-left: 15px;
    }

    .box {
      border: 1px solid #ddd;
      padding: 25px;
      margin-top: 15px;
      border-radius: 12px;
      background-color: #f9f9f9;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .highlight-box {
      background: linear-gradient(135deg, #e0f2f1 0%, #f1f8e9 100%);
      border: 2px solid #2A9D8F;
      padding: 30px;
      border-radius: 15px;
      margin: 25px 0;
    }

    .metrics-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin: 20px 0;
    }

    .metric-card {
      background: white;
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      border: 1px solid #e0e0e0;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .metric-value {
      font-size: 2.5em;
      font-weight: bold;
      color: #2A9D8F;
      margin-bottom: 5px;
    }

    .metric-label {
      font-size: 0.9em;
      color: #666;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .category-block {
      margin-bottom: 30px;
      padding: 20px;
      background: white;
      border-radius: 10px;
      border-left: 4px solid #2A9D8F;
      box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .category-header {
      display: flex;
      align-items: center;
      margin-bottom: 15px;
    }

    .category-score {
      font-size: 1.8em;
      font-weight: bold;
      margin-left: auto;
    }

    .recommendations {
      background: linear-gradient(135deg, #fff3e0 0%, #f3e5f5 100%);
      border: 2px solid #ff9800;
      padding: 25px;
      border-radius: 15px;
      margin: 20px 0;
    }

    .recommendations h3 {
      color: #e65100;
      margin-top: 0;
    }

    .footer {
      text-align: center;
      border-top: 2px solid #2A9D8F;
      padding-top: 20px;
      margin-top: 50px;
      font-size: 0.9em;
      color: #666;
    }

    .test-banner {
      background: #ff9800;
      color: white;
      text-align: center;
      padding: 15px;
      margin: -40px -40px 40px -40px;
      font-weight: bold;
      font-size: 1.2em;
    }
  </style>
</head>
<body>

  <div class="test-banner">
    🧪 TEST REPORT - PDF Generation System Demo
  </div>

  <div class="header">
    <h1>Leadership Clarity Audit Report</h1>
    <p>Prepared for: Chloe James</p>
    <p>Generated on: ${new Date().toLocaleDateString()}</p>
  </div>

  <div class="section">
    <h2>Audit Overview</h2>
    <div class="highlight-box">
      <div class="metrics-grid">
        <div class="metric-card">
          <div class="metric-value">4.2</div>
          <div class="metric-label">Overall Score</div>
        </div>
        <div class="metric-card">
          <div class="metric-value">Very Strong</div>
          <div class="metric-label">Performance Level</div>
        </div>
        <div class="metric-card">
          <div class="metric-value">Leadership Alignment</div>
          <div class="metric-label">Strongest Area</div>
        </div>
        <div class="metric-card">
          <div class="metric-value">Team Performance</div>
          <div class="metric-label">Development Area</div>
        </div>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>Category Breakdown</h2>
    
    <div class="category-block">
      <div class="category-header">
        <div>
          <h3>Team Performance</h3>
          <p>Strong</p>
        </div>
        <div class="category-score" style="color: #2A9D8F">
          3.8
        </div>
      </div>
      
      <p>Your leadership team has solid performance foundations. Focus on improving decision-making speed and translating strategy into clearer action plans.</p>
      
      <div style="margin-top: 15px; padding: 10px; background-color: #fff3cd; border-left: 4px solid #ffc107; border-radius: 4px;">
        <strong>Priority Focus Area:</strong> This is your lowest-scoring category and should be addressed first.
      </div>
    </div>
    
    <div class="category-block">
      <div class="category-header">
        <div>
          <h3>Values & Culture</h3>
          <p>Very Strong</p>
        </div>
        <div class="category-score" style="color: #264653">
          4.2
        </div>
      </div>
      
      <p>Your leadership team effectively models values and creates a positive culture. Continue strengthening your communication of the 'why' behind decisions.</p>
    </div>
    
    <div class="category-block">
      <div class="category-header">
        <div>
          <h3>Leadership Alignment</h3>
          <p>Exceptional</p>
        </div>
        <div class="category-score" style="color: #2A9D8F">
          4.6
        </div>
      </div>
      
      <p>Your leadership team demonstrates strong alignment and unity. Continue refining role clarity and maintaining your effective conflict resolution practices.</p>
      
      <div style="margin-top: 15px; padding: 10px; background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 4px;">
        <strong>Strength to Leverage:</strong> This is your highest-scoring category. Build on these strengths.
      </div>
    </div>
    
    <div class="category-block">
      <div class="category-header">
        <div>
          <h3>People & Retention</h3>
          <p>Very Strong</p>
        </div>
        <div class="category-score" style="color: #264653">
          4.2
        </div>
      </div>
      
      <p>Your leadership team excels at developing people and maintaining engagement. Continue your strong practices in talent development and feedback.</p>
    </div>
  </div>

  <div class="section">
    <h2>Overall Assessment</h2>
    <div class="box">
      <h3>Strong Leadership Team</h3>
      <p>Your leadership team is performing well with clear strengths. There are specific areas where targeted improvements can take you from good to great.</p>
      
      <div style="margin-top: 20px;">
        <h4>Recommended Actions:</h4>
        <ul>
          <li>Build on your strengths while addressing your lowest-scoring category</li>
          <li>Implement regular leadership team effectiveness reviews</li>
          <li>Create development plans for each leader that align with team goals</li>
        </ul>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>Next Steps</h2>
    <div class="recommendations">
      <h3>Taking Action on Your Results</h3>
      
      <p>To make the most of this assessment:</p>
      <ol>
        <li><strong>Share these insights</strong> with your leadership team</li>
        <li><strong>Focus first</strong> on your lowest-scoring category</li>
        <li><strong>Create an action plan</strong> with specific, measurable goals</li>
        <li><strong>Schedule a follow-up assessment</strong> in 3-6 months to track progress</li>
      </ol>
      
      <div style="margin-top: 25px; padding: 20px; background: rgba(255,255,255,0.7); border-radius: 10px;">
        <h4 style="margin-top: 0; color: #2A9D8F;">Need Support?</h4>
        <p>Book a free 30-minute strategy call to discuss your results and get personalized guidance on implementing these recommendations.</p>
        <p style="margin-bottom: 0;"><strong>Visit:</strong> <a href="https://calendly.com/chloe-cultivatedhq/30min">calendly.com/chloe-cultivatedhq/30min</a></p>
      </div>
    </div>
  </div>

  <div class="footer">
    <p><strong>Generated on ${new Date().toLocaleDateString()} | Cultivated HQ</strong></p>
    <p>For questions about this report or leadership development support, contact: <strong>chloe@cultivatedhq.com.au</strong></p>
    <p style="margin-top: 15px; font-size: 0.8em;">
      This report contains confidential leadership insights. Please handle with appropriate discretion.
    </p>
  </div>

</body>
</html>
    `

    console.log('📄 HTML report generated, calling PDF.co...')

    // Generate PDF using PDF.co
    const pdfResponse = await fetch('https://api.pdf.co/v1/pdf/convert/from/html', {
      method: 'POST',
      headers: {
        'x-api-key': 'cbjames674@gmail.com_C8Qxi0EeYZPsuFleKhRErEynYQ12d16f2TttcgYaMpKOtP3aHlBHTNvG64EynWbR',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        html: htmlReport,
        name: `Test-Leadership-Clarity-Audit-${new Date().toISOString().split('T')[0]}.pdf`,
        async: false,
        margins: '20px',
        paperSize: 'A4',
        orientation: 'Portrait',
        printBackground: true,
        mediaType: 'print'
      })
    })

    const pdfResult = await pdfResponse.json()

    if (!pdfResponse.ok) {
      throw new Error(`PDF.co error: ${pdfResult.message || 'Unknown error'}`)
    }

    console.log('✅ PDF generated successfully:', pdfResult.url)

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Test PDF report generated successfully!',
        pdf_url: pdfResult.url,
        pdf_name: pdfResult.name,
        test_data: {
          title: "Leadership Clarity Audit - Test Report",
          manager_name: "Chloe James",
          manager_email: "chloe@cultivatedhq.com.au",
          total_score: 4.2,
          highest_category: "Leadership Alignment",
          lowest_category: "Team Performance"
        },
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('💥 Error generating test PDF:', error)
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false,
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})