/*
  # Fix Row Level Security for Clarity Audit Results

  1. Changes
    - Drop existing RLS policies on clarity_audit_results that may be conflicting
    - Create a new, more permissive policy for anonymous users to insert results
    - Ensure authenticated users can also manage results
    - Grant necessary permissions to both roles

  2. Security
    - Allows anonymous users to insert their audit results
    - Maintains security while enabling the audit functionality
*/

-- Drop existing policies that might be causing conflicts
DROP POLICY IF EXISTS "Anon users can insert audit results" ON clarity_audit_results;
DROP POLICY IF EXISTS "Authenticated users can read all audit results" ON clarity_audit_results;

-- Create a completely permissive policy for anonymous users to insert results
CREATE POLICY "Anonymous users can insert audit results"
  ON clarity_audit_results
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow authenticated users to read all results
CREATE POLICY "Authenticated users can read all audit results"
  ON clarity_audit_results
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow authenticated users to update results (for adding PDF URLs)
CREATE POLICY "Authenticated users can update audit results"
  ON clarity_audit_results
  FOR UPDATE
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT INSERT ON clarity_audit_results TO anon;
GRANT SELECT, UPDATE ON clarity_audit_results TO authenticated;
GRANT ALL ON clarity_audit_results TO service_role;