/*
  # Create Feedback System Tables

  1. New Tables
    - `feedback_sessions`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text, optional)
      - `questions` (jsonb array)
      - `scale_type` (text, likert_5 or likert_7)
      - `is_active` (boolean)
      - `is_public` (boolean) - distinguishes between public self-serve and private admin sessions
      - `manager_name` (text)
      - `manager_email` (text)
      - `response_count` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `feedback_responses`
      - `id` (uuid, primary key)
      - `session_id` (uuid, foreign key)
      - `responses` (jsonb array)
      - `comment` (text, optional)
      - `submitted_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Allow anonymous users to read active sessions and submit responses
    - Allow authenticated users (admin) to manage all sessions and read responses
    - Public sessions can be read by anyone, private sessions only by admin

  3. Functions & Triggers
    - Auto-update response count when responses are added/removed
    - Auto-update updated_at timestamp
*/

-- Create feedback_sessions table
CREATE TABLE IF NOT EXISTS feedback_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  questions jsonb NOT NULL DEFAULT '[]'::jsonb,
  scale_type text NOT NULL DEFAULT 'likert_5' CHECK (scale_type IN ('likert_5', 'likert_7')),
  is_active boolean NOT NULL DEFAULT true,
  is_public boolean NOT NULL DEFAULT false,
  manager_name text NOT NULL,
  manager_email text NOT NULL,
  response_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create feedback_responses table
CREATE TABLE IF NOT EXISTS feedback_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES feedback_sessions(id) ON DELETE CASCADE,
  responses jsonb NOT NULL DEFAULT '[]'::jsonb,
  comment text,
  submitted_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE feedback_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback_responses ENABLE ROW LEVEL SECURITY;

-- Policies for feedback_sessions
-- Allow anonymous users to read active public sessions
CREATE POLICY "Anyone can read active public sessions"
  ON feedback_sessions
  FOR SELECT
  TO anon
  USING (is_active = true AND is_public = true);

-- Allow anonymous users to insert public sessions (self-serve)
CREATE POLICY "Anyone can create public sessions"
  ON feedback_sessions
  FOR INSERT
  TO anon
  WITH CHECK (is_public = true);

-- Allow authenticated users (admin) to manage all sessions
CREATE POLICY "Authenticated users can manage all sessions"
  ON feedback_sessions
  FOR ALL
  TO authenticated
  USING (true);

-- Policies for feedback_responses
-- Allow anonymous users to insert responses for active sessions
CREATE POLICY "Anyone can submit responses to active sessions"
  ON feedback_responses
  FOR INSERT
  TO anon
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM feedback_sessions 
      WHERE id = session_id AND is_active = true
    )
  );

-- Allow authenticated users (admin) to read all responses
CREATE POLICY "Authenticated users can read all responses"
  ON feedback_responses
  FOR SELECT
  TO authenticated
  USING (true);

-- Function to update response count
CREATE OR REPLACE FUNCTION update_response_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE feedback_sessions 
    SET response_count = response_count + 1,
        updated_at = now()
    WHERE id = NEW.session_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE feedback_sessions 
    SET response_count = response_count - 1,
        updated_at = now()
    WHERE id = OLD.session_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update response count
DROP TRIGGER IF EXISTS trigger_update_response_count ON feedback_responses;
CREATE TRIGGER trigger_update_response_count
  AFTER INSERT OR DELETE ON feedback_responses
  FOR EACH ROW
  EXECUTE FUNCTION update_response_count();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update updated_at on feedback_sessions
DROP TRIGGER IF EXISTS trigger_update_sessions_updated_at ON feedback_sessions;
CREATE TRIGGER trigger_update_sessions_updated_at
  BEFORE UPDATE ON feedback_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_feedback_sessions_active ON feedback_sessions(is_active);
CREATE INDEX IF NOT EXISTS idx_feedback_sessions_public ON feedback_sessions(is_public);
CREATE INDEX IF NOT EXISTS idx_feedback_sessions_created_at ON feedback_sessions(created_at);
CREATE INDEX IF NOT EXISTS idx_feedback_sessions_manager_email ON feedback_sessions(manager_email);
CREATE INDEX IF NOT EXISTS idx_feedback_responses_session_id ON feedback_responses(session_id);
CREATE INDEX IF NOT EXISTS idx_feedback_responses_submitted_at ON feedback_responses(submitted_at);