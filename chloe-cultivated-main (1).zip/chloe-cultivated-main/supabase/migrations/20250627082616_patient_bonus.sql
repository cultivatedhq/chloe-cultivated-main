/*
  # Survey Processing Views and Functions

  1. Views
    - session_expiration_status: Shows surveys ready for processing
    - survey_analytics: Provides comprehensive analytics for any survey
  
  2. Functions
    - get_performance_category: Determines performance level based on scores
    - calculate_question_stats: Calculates statistics for survey questions
    - get_survey_responses: Gets responses for a specific survey
    - get_survey_comments: Gets comments for a specific survey
    - process_survey_completion: Marks survey as processed

  3. Security
    - All views and functions respect existing RLS policies
    - Functions are security definer where appropriate
*/

-- 1. Create view for surveys ready for processing
CREATE OR REPLACE VIEW session_expiration_status AS
SELECT 
  id,
  title,
  manager_name,
  manager_email,
  created_at,
  expires_at,
  response_count,
  is_active,
  report_generated,
  report_sent,
  report_sent_at,
  CASE 
    WHEN expires_at <= NOW() AND is_active = true AND report_sent = false THEN 'expired_pending'
    WHEN expires_at <= NOW() AND report_sent = true THEN 'expired_processed'
    WHEN expires_at > NOW() AND is_active = true THEN 'active'
    ELSE 'inactive'
  END as status,
  CASE 
    WHEN expires_at <= NOW() THEN 0
    ELSE EXTRACT(EPOCH FROM (expires_at - NOW())) / 3600
  END as hours_remaining
FROM feedback_sessions
ORDER BY expires_at ASC;

-- 2. Performance category classification function
CREATE OR REPLACE FUNCTION get_performance_category(average_score numeric, scale_max integer)
RETURNS text AS $$
BEGIN
  DECLARE
    percentage numeric;
  BEGIN
    percentage := (average_score / scale_max) * 100;
    
    IF percentage >= 80 THEN
      RETURN 'excellent';
    ELSIF percentage >= 60 THEN
      RETURN 'good';
    ELSIF percentage >= 40 THEN
      RETURN 'fair';
    ELSE
      RETURN 'needs_improvement';
    END IF;
  END;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 3. Function to get responses for a specific survey
CREATE OR REPLACE FUNCTION get_survey_responses(survey_id uuid)
RETURNS TABLE (
  id uuid,
  responses jsonb,
  comment text,
  submitted_at timestamptz,
  question_count integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    fr.id,
    fr.responses,
    fr.comment,
    fr.submitted_at,
    jsonb_array_length(fr.responses) as question_count
  FROM feedback_responses fr
  WHERE fr.session_id = survey_id
  ORDER BY fr.submitted_at ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Function to get comments for a specific survey
CREATE OR REPLACE FUNCTION get_survey_comments(survey_id uuid)
RETURNS TABLE (
  comment text,
  submitted_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    fr.comment,
    fr.submitted_at
  FROM feedback_responses fr
  WHERE fr.session_id = survey_id
    AND fr.comment IS NOT NULL
    AND TRIM(fr.comment) != ''
  ORDER BY fr.submitted_at ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Function to calculate question statistics
CREATE OR REPLACE FUNCTION calculate_question_stats(survey_id uuid, scale_max integer)
RETURNS TABLE (
  question_index integer,
  average_score numeric,
  median_score numeric,
  total_responses bigint,
  distribution json
) AS $$
BEGIN
  RETURN QUERY
  WITH question_analysis AS (
    SELECT 
      (row_number() OVER (PARTITION BY fr.id ORDER BY ordinality)) - 1 as q_index,
      (response_val::text)::numeric as response_value
    FROM feedback_responses fr,
         jsonb_array_elements(fr.responses) WITH ORDINALITY as response_val(value, ordinality)
    WHERE fr.session_id = survey_id
      AND (response_val::text)::numeric > 0
      AND (response_val::text)::numeric <= scale_max
  ),
  question_stats AS (
    SELECT 
      q_index,
      ROUND(AVG(response_value), 2) as avg_score,
      PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY response_value) as med_score,
      COUNT(*) as total_resp
    FROM question_analysis
    GROUP BY q_index
  ),
  distribution_data AS (
    SELECT 
      q_index,
      response_value,
      COUNT(*) as value_count
    FROM question_analysis
    GROUP BY q_index, response_value
  )
  SELECT 
    qs.q_index::integer,
    qs.avg_score,
    qs.med_score,
    qs.total_resp,
    COALESCE(
      json_object_agg(dd.response_value::text, dd.value_count),
      '{}'::json
    ) as dist
  FROM question_stats qs
  LEFT JOIN distribution_data dd ON qs.q_index = dd.q_index
  GROUP BY qs.q_index, qs.avg_score, qs.med_score, qs.total_resp
  ORDER BY qs.q_index;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 6. Function to get overall survey metrics
CREATE OR REPLACE FUNCTION get_survey_metrics(survey_id uuid, scale_max integer)
RETURNS TABLE (
  overall_average numeric,
  strongest_question_index integer,
  strongest_score numeric,
  weakest_question_index integer,
  weakest_score numeric,
  questions_with_responses bigint,
  performance_category text
) AS $$
BEGIN
  RETURN QUERY
  WITH question_averages AS (
    SELECT 
      (row_number() OVER (PARTITION BY fr.id ORDER BY ordinality)) - 1 as q_index,
      AVG((response_val::text)::numeric) as avg_score
    FROM feedback_responses fr,
         jsonb_array_elements(fr.responses) WITH ORDINALITY as response_val(value, ordinality)
    WHERE fr.session_id = survey_id
      AND (response_val::text)::numeric > 0
      AND (response_val::text)::numeric <= scale_max
    GROUP BY fr.id, ordinality
  ),
  aggregated_averages AS (
    SELECT 
      q_index,
      AVG(avg_score) as final_avg
    FROM question_averages
    GROUP BY q_index
  ),
  overall_stats AS (
    SELECT 
      ROUND(AVG(final_avg), 2) as overall_avg,
      COUNT(*) as question_count
    FROM aggregated_averages
  ),
  strongest AS (
    SELECT 
      q_index as strongest_idx,
      final_avg as strongest_val
    FROM aggregated_averages
    WHERE final_avg = (SELECT MAX(final_avg) FROM aggregated_averages)
    LIMIT 1
  ),
  weakest AS (
    SELECT 
      q_index as weakest_idx,
      final_avg as weakest_val
    FROM aggregated_averages
    WHERE final_avg = (SELECT MIN(final_avg) FROM aggregated_averages)
    LIMIT 1
  )
  SELECT 
    os.overall_avg,
    s.strongest_idx::integer,
    s.strongest_val,
    w.weakest_idx::integer,
    w.weakest_val,
    os.question_count,
    get_performance_category(os.overall_avg, scale_max)
  FROM overall_stats os
  CROSS JOIN strongest s
  CROSS JOIN weakest w;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 7. Function to mark survey as processed
CREATE OR REPLACE FUNCTION process_survey_completion(survey_id uuid)
RETURNS boolean AS $$
BEGIN
  UPDATE feedback_sessions 
  SET 
    is_active = false,
    report_generated = true,
    report_sent = true,
    report_sent_at = NOW(),
    updated_at = NOW()
  WHERE id = survey_id;
  
  RETURN FOUND;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 8. Comprehensive survey analysis function
CREATE OR REPLACE FUNCTION get_complete_survey_analysis(survey_id uuid)
RETURNS TABLE (
  session_data json,
  response_count bigint,
  question_analytics json,
  overall_metrics json,
  comments_data json,
  processing_status text,
  processed_at timestamptz
) AS $$
DECLARE
  session_record feedback_sessions%ROWTYPE;
  scale_max integer;
  response_cnt bigint;
BEGIN
  -- Get session information
  SELECT * INTO session_record
  FROM feedback_sessions
  WHERE id = survey_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Survey not found: %', survey_id;
  END IF;
  
  -- Determine scale max
  scale_max := CASE WHEN session_record.scale_type = 'likert_7' THEN 7 ELSE 5 END;
  
  -- Get response count
  SELECT COUNT(*) INTO response_cnt
  FROM feedback_responses
  WHERE session_id = survey_id;
  
  RETURN QUERY
  SELECT 
    -- Session data as JSON
    row_to_json(session_record)::json,
    
    -- Response count
    response_cnt,
    
    -- Question analytics as JSON
    COALESCE(
      (SELECT json_agg(
        json_build_object(
          'question_index', question_index,
          'average_score', average_score,
          'median_score', median_score,
          'total_responses', total_responses,
          'distribution', distribution
        )
      )
      FROM calculate_question_stats(survey_id, scale_max)),
      '[]'::json
    ),
    
    -- Overall metrics as JSON
    COALESCE(
      (SELECT row_to_json(metrics)
      FROM get_survey_metrics(survey_id, scale_max) metrics),
      '{}'::json
    ),
    
    -- Comments as JSON
    COALESCE(
      (SELECT json_agg(
        json_build_object(
          'comment', comment,
          'submitted_at', submitted_at
        )
      )
      FROM get_survey_comments(survey_id)),
      '[]'::json
    ),
    
    -- Processing status
    CASE 
      WHEN response_cnt > 0 THEN 'ready_for_report'
      ELSE 'no_responses'
    END,
    
    -- Processed timestamp
    NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. Grant necessary permissions
GRANT SELECT ON session_expiration_status TO anon, authenticated;
GRANT EXECUTE ON FUNCTION get_performance_category(numeric, integer) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION get_survey_responses(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION get_survey_comments(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_question_stats(uuid, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION get_survey_metrics(uuid, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION process_survey_completion(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION get_complete_survey_analysis(uuid) TO authenticated;

-- 10. Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_feedback_sessions_expiration_processing 
ON feedback_sessions (expires_at, is_active, report_sent) 
WHERE is_active = true AND report_sent = false;

CREATE INDEX IF NOT EXISTS idx_feedback_responses_session_processing 
ON feedback_responses (session_id, submitted_at);