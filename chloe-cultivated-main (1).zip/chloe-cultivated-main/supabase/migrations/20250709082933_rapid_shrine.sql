/*
  # Add PDF URL to Clarity Audit Results

  1. New Columns
    - `pdf_url` (text) - URL to the generated PDF report
    
  2. Purpose
    - Store the URL to the generated PDF report for future reference
    - Allow users to access their report again if needed
*/

-- Add PDF URL column to clarity_audit_results
ALTER TABLE clarity_audit_results 
ADD COLUMN IF NOT EXISTS pdf_url text;

-- Create a table to store the PDF.co API key
CREATE TABLE IF NOT EXISTS "PDFCO_API_KEY" (
  id bigint PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Insert the API key as a comment on the table
COMMENT ON TABLE "PDFCO_API_KEY" IS 'cbjames674@gmail.com_C8Qxi0EeYZPsuFleKhRErEynYQ12d16f2TttcgYaMpKOtP3aHlBHTNvG64EynWbR';

-- Enable RLS on the API key table
ALTER TABLE "PDFCO_API_KEY" ENABLE ROW LEVEL SECURITY;