/*
  # Add Survey Expiration and Report Tracking

  1. New Columns
    - `expires_at` (timestamptz) - When the survey expires (3 days from creation)
    - `report_generated` (boolean) - Whether a report has been generated
    - `report_sent` (boolean) - Whether the report has been sent
    - `report_sent_at` (timestamptz) - When the report was sent

  2. Functions
    - Function to automatically set expiration date on new sessions
    - Function to check if a session is expired
    - Function to process expired sessions

  3. Indexes
    - Indexes for efficient expiration queries

  4. Views
    - View for easy expiration status checking
*/

-- Add expiration tracking columns
ALTER TABLE feedback_sessions 
ADD COLUMN IF NOT EXISTS expires_at timestamptz DEFAULT (now() + interval '3 days');

ALTER TABLE feedback_sessions 
ADD COLUMN IF NOT EXISTS report_generated boolean DEFAULT false;

ALTER TABLE feedback_sessions 
ADD COLUMN IF NOT EXISTS report_sent boolean DEFAULT false;

ALTER TABLE feedback_sessions 
ADD COLUMN IF NOT EXISTS report_sent_at timestamptz;

-- Update existing sessions to have expiration dates
UPDATE feedback_sessions 
SET expires_at = created_at + interval '3 days'
WHERE expires_at IS NULL;

-- Make expires_at NOT NULL going forward
ALTER TABLE feedback_sessions 
ALTER COLUMN expires_at SET NOT NULL;

-- Function to automatically set expiration date for new sessions
CREATE OR REPLACE FUNCTION set_session_expiration()
RETURNS TRIGGER AS $$
BEGIN
  -- Set expiration to 3 days from creation
  NEW.expires_at = NEW.created_at + interval '3 days';
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new sessions
DROP TRIGGER IF EXISTS trigger_set_session_expiration ON feedback_sessions;
CREATE TRIGGER trigger_set_session_expiration
  BEFORE INSERT ON feedback_sessions
  FOR EACH ROW
  EXECUTE FUNCTION set_session_expiration();

-- Function to check if a session is expired
CREATE OR REPLACE FUNCTION is_session_expired(session_row feedback_sessions)
RETURNS boolean AS $$
BEGIN
  RETURN now() > session_row.expires_at;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Update RLS policies to consider expiration
DROP POLICY IF EXISTS "Anyone can read active public sessions" ON feedback_sessions;
CREATE POLICY "Anyone can read active public sessions"
  ON feedback_sessions
  FOR SELECT
  TO anon
  USING (is_active = true AND is_public = true AND now() <= expires_at);

-- Update response policy to check session expiration
DROP POLICY IF EXISTS "Anyone can submit responses to active sessions" ON feedback_responses;
CREATE POLICY "Anyone can submit responses to active sessions"
  ON feedback_responses
  FOR INSERT
  TO anon
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM feedback_sessions 
      WHERE id = session_id 
      AND is_active = true 
      AND now() <= expires_at
    )
  );

-- Create indexes for efficient expiration queries
CREATE INDEX IF NOT EXISTS idx_feedback_sessions_expires_at ON feedback_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_feedback_sessions_expired_unreported ON feedback_sessions(expires_at, is_active, report_generated) 
  WHERE is_active = true AND report_generated = false;

-- Create a view for easy expiration checking
CREATE OR REPLACE VIEW session_expiration_status AS
SELECT 
  id,
  title,
  manager_name,
  manager_email,
  created_at,
  expires_at,
  response_count,
  is_active,
  report_generated,
  report_sent,
  report_sent_at,
  CASE 
    WHEN now() > expires_at THEN 'expired'
    WHEN now() > (expires_at - interval '24 hours') THEN 'expiring_soon'
    ELSE 'active'
  END as status,
  EXTRACT(EPOCH FROM (expires_at - now())) / 3600 as hours_remaining
FROM feedback_sessions
WHERE is_public = true;