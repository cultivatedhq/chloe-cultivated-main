-- Drop the existing policy that's causing the error
DROP POLICY IF EXISTS "Anyone can submit responses to active sessions" ON feedback_responses;

-- Create a new, more permissive policy for anonymous users
CREATE POLICY "Anyone can submit responses to active sessions"
  ON feedback_responses
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Update the policy for reading responses to be more explicit
DROP POLICY IF EXISTS "Authenticated users can read all responses" ON feedback_responses;

CREATE POLICY "Authenticated users can read all responses"
  ON feedback_responses
  FOR SELECT
  TO authenticated
  USING (true);

-- Drop the policy if it exists to avoid errors
DROP POLICY IF EXISTS "Anonymous users can read their own responses" ON feedback_responses;

-- Grant necessary permissions
GRANT INSERT, SELECT ON feedback_responses TO anon;
GRANT ALL ON feedback_responses TO authenticated;