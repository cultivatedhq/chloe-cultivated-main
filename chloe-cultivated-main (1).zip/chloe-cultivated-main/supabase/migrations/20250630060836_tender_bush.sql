/*
  # Fix RLS Policies for Feedback Responses

  This migration fixes the Row Level Security (RLS) policies for the feedback_responses table
  to ensure that anonymous users can submit responses and read their own responses.
*/

-- Drop existing policies that might be causing conflicts
DROP POLICY IF EXISTS "Anyone can submit responses to active sessions" ON feedback_responses;
DROP POLICY IF EXISTS "Anon users can submit responses" ON feedback_responses;
DROP POLICY IF EXISTS "Anonymous users can read their own responses" ON feedback_responses;
DROP POLICY IF EXISTS "Anon users can read responses from active sessions" ON feedback_responses;

-- Create a completely permissive policy for anonymous users to insert responses
CREATE POLICY "Anon users can insert responses"
  ON feedback_responses
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Create a policy for anonymous users to read responses
CREATE POLICY "Anon users can read responses"
  ON feedback_responses
  FOR SELECT
  TO anon
  USING (true);

-- Ensure authenticated users can read all responses
DROP POLICY IF EXISTS "Authenticated users can read all responses" ON feedback_responses;
CREATE POLICY "Authenticated users can read all responses"
  ON feedback_responses
  FOR SELECT
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT INSERT, SELECT ON feedback_responses TO anon;
GRANT ALL ON feedback_responses TO authenticated;