/*
  # Add Clarity Audit Results Table

  1. New Table
    - `clarity_audit_results`
      - `id` (uuid, primary key)
      - `email` (text) - User's email address
      - `name` (text, optional) - User's name if provided
      - `answers` (jsonb) - Raw answers to each question
      - `category_scores` (jsonb) - Scores for each category
      - `total_score` (numeric) - Overall audit score
      - `lowest_category` (text) - Category with lowest score
      - `highest_category` (text) - Category with highest score
      - `created_at` (timestamptz) - When the audit was completed

  2. Security
    - Enable RLS on the table
    - Allow anonymous users to insert results
    - Allow authenticated users to read all results
*/

-- Create clarity_audit_results table
CREATE TABLE IF NOT EXISTS clarity_audit_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  name text,
  answers jsonb NOT NULL,
  category_scores jsonb NOT NULL,
  total_score numeric NOT NULL,
  lowest_category text,
  highest_category text,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_clarity_audit_results_email ON clarity_audit_results(email);
CREATE INDEX IF NOT EXISTS idx_clarity_audit_results_created_at ON clarity_audit_results(created_at);

-- Enable RLS
ALTER TABLE clarity_audit_results ENABLE ROW LEVEL SECURITY;

-- Policies for clarity_audit_results
-- Allow anonymous users to insert results
CREATE POLICY "Anon users can insert audit results"
  ON clarity_audit_results
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow authenticated users to read all results
CREATE POLICY "Authenticated users can read all audit results"
  ON clarity_audit_results
  FOR SELECT
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT INSERT ON clarity_audit_results TO anon;
GRANT SELECT ON clarity_audit_results TO authenticated;