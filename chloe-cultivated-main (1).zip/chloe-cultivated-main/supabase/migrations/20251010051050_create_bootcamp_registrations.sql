/*
  # Create Bootcamp Registrations Table

  ## Overview
  This migration creates a table to store Leadership Bootcamp enrollment registrations.
  It captures user information when they express interest in enrolling in the bootcamp
  program, allowing Chloe to follow up personally with each registrant.

  ## New Tables
  
  ### `bootcamp_registrations`
  Stores enrollment registration data for the Leadership Bootcamp program.
  
  **Columns:**
  - `id` (uuid, primary key) - Unique identifier for each registration
  - `first_name` (text, required) - Registrant's first name
  - `last_name` (text, required) - Registrant's last name
  - `email` (text, required) - Registrant's email address
  - `phone` (text, optional) - Registrant's phone number
  - `company` (text, optional) - Company name where registrant works
  - `leadership_role` (text, optional) - Current leadership role or position
  - `years_in_leadership` (text, optional) - Years of leadership experience
  - `funding_type` (text, required) - How they plan to fund (company_sponsored or self_funded)
  - `additional_notes` (text, optional) - Any additional information or questions
  - `created_at` (timestamptz) - Timestamp when registration was submitted
  - `updated_at` (timestamptz) - Timestamp when registration was last updated

  ## Security
  
  ### Row Level Security (RLS)
  - RLS is enabled on the `bootcamp_registrations` table
  - Anonymous users can INSERT new registrations (for form submissions)
  - Authenticated users (admin) can SELECT all registrations
  - Authenticated users (admin) can UPDATE and DELETE registrations
  
  ### Policies
  1. **Anyone can submit registrations** - Allows anonymous form submissions
  2. **Authenticated users can view registrations** - Admin can see all registrations
  3. **Authenticated users can update registrations** - Admin can modify records
  4. **Authenticated users can delete registrations** - Admin can remove records
  
  ## Indexes
  - Index on `email` for quick lookups and duplicate checking
  - Index on `created_at` for chronological queries
  - Index on `funding_type` for filtering by funding method
  
  ## Notes
  - Email validation should be handled at the application level
  - The table allows anonymous insertions to support public form submissions
  - Admin access requires authentication for viewing and managing registrations
  - Default values are provided for boolean and timestamp fields
*/

-- Create bootcamp_registrations table
CREATE TABLE IF NOT EXISTS bootcamp_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text NOT NULL,
  phone text,
  company text,
  leadership_role text,
  years_in_leadership text,
  funding_type text NOT NULL CHECK (funding_type IN ('company_sponsored', 'self_funded')),
  additional_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE bootcamp_registrations ENABLE ROW LEVEL SECURITY;

-- Policy: Allow anonymous users to insert registrations (form submissions)
CREATE POLICY "Anyone can submit bootcamp registrations"
  ON bootcamp_registrations
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Policy: Allow authenticated users to view all registrations
CREATE POLICY "Authenticated users can view bootcamp registrations"
  ON bootcamp_registrations
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy: Allow authenticated users to update registrations
CREATE POLICY "Authenticated users can update bootcamp registrations"
  ON bootcamp_registrations
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policy: Allow authenticated users to delete registrations
CREATE POLICY "Authenticated users can delete bootcamp registrations"
  ON bootcamp_registrations
  FOR DELETE
  TO authenticated
  USING (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_bootcamp_registrations_email 
  ON bootcamp_registrations(email);

CREATE INDEX IF NOT EXISTS idx_bootcamp_registrations_created_at 
  ON bootcamp_registrations(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_bootcamp_registrations_funding_type 
  ON bootcamp_registrations(funding_type);

-- Function to auto-update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_bootcamp_registrations_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update updated_at on row updates
DROP TRIGGER IF EXISTS trigger_update_bootcamp_registrations_updated_at ON bootcamp_registrations;
CREATE TRIGGER trigger_update_bootcamp_registrations_updated_at
  BEFORE UPDATE ON bootcamp_registrations
  FOR EACH ROW
  EXECUTE FUNCTION update_bootcamp_registrations_updated_at();