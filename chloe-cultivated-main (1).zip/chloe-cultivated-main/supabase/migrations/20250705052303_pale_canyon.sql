/*
  # Add Survey Processing Logging System

  1. New Table
    - `survey_processing_logs` - Stores detailed logs of survey processing steps
      - `id` (uuid, primary key)
      - `survey_id` (uuid, references feedback_sessions)
      - `status` (text) - Processing status code
      - `message` (text, optional) - Additional details or error message
      - `created_at` (timestamptz) - When the log entry was created

  2. Functions
    - `log_survey_processing` - Inserts records into the logging table
    
  3. Views
    - `survey_processing_log_view` - Joins logs with survey details for easier querying
*/

-- Create survey processing logs table
CREATE TABLE IF NOT EXISTS survey_processing_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_id uuid NOT NULL REFERENCES feedback_sessions(id) ON DELETE CASCADE,
  status text NOT NULL,
  message text,
  created_at timestamptz DEFAULT now()
);

-- Create index for efficient querying
CREATE INDEX IF NOT EXISTS idx_survey_processing_logs_survey_id ON survey_processing_logs(survey_id);
CREATE INDEX IF NOT EXISTS idx_survey_processing_logs_status ON survey_processing_logs(status);
CREATE INDEX IF NOT EXISTS idx_survey_processing_logs_created_at ON survey_processing_logs(created_at);

-- Enable RLS
ALTER TABLE survey_processing_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated users can manage all logs"
  ON survey_processing_logs
  FOR ALL
  TO authenticated
  USING (true);

-- Drop the function if it exists to avoid return type error
DROP FUNCTION IF EXISTS log_survey_processing(uuid, text, text);

-- Create the logging function
CREATE OR REPLACE FUNCTION log_survey_processing(
  survey_id uuid,
  status text,
  message text DEFAULT NULL
) RETURNS uuid AS $$
DECLARE
  log_id uuid;
BEGIN
  INSERT INTO survey_processing_logs (survey_id, status, message)
  VALUES (survey_id, status, message)
  RETURNING id INTO log_id;
  
  RETURN log_id;
EXCEPTION WHEN OTHERS THEN
  -- If logging fails, don't fail the entire operation
  RAISE NOTICE 'Failed to log survey processing: %', SQLERRM;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION log_survey_processing(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION log_survey_processing(uuid, text, text) TO anon;

-- Create a view for easy access to survey processing logs with survey details
CREATE OR REPLACE VIEW survey_processing_log_view AS
SELECT 
  spl.id as log_id,
  spl.survey_id,
  fs.title as survey_title,
  fs.manager_name,
  fs.manager_email,
  spl.status,
  spl.message,
  spl.created_at as logged_at,
  fs.response_count,
  fs.report_sent,
  fs.report_sent_at
FROM survey_processing_logs spl
JOIN feedback_sessions fs ON spl.survey_id = fs.id
ORDER BY spl.created_at DESC;

-- Grant access to the view
GRANT SELECT ON survey_processing_log_view TO authenticated;