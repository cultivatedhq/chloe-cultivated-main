/*
  # Cron Job Setup for Survey Processing

  1. Purpose
    - Set up a daily cron job to process expired surveys
    - Automatically call the process-expired-sessions function
    
  2. Requirements
    - pg_cron extension must be enabled
    - Supabase service role key must be available
    
  3. Schedule
    - Daily at 8:00 AM
*/

-- This migration is for documentation purposes only
-- The actual cron job setup must be done in the Supabase dashboard or via the CLI
-- as it requires the pg_cron extension which may not be available in all environments

/*
-- Enable pg_cron extension (requires superuser privileges)
-- CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule daily processing at 8:00 AM
-- SELECT cron.schedule(
--   'process-expired-surveys',
--   '0 8 * * *',
--   $$
--   SELECT net.http_post(
--     url := 'https://your-project.supabase.co/functions/v1/process-expired-sessions',
--     headers := '{"Authorization": "Bearer your-service-role-key"}'::jsonb
--   );
--   $$
-- );
*/

-- Alternative: Create a function that can be called manually
-- This can be used if automatic scheduling is not available
CREATE OR REPLACE FUNCTION trigger_expired_survey_processing()
RETURNS json AS $$
DECLARE
  result json;
BEGIN
  -- Call the edge function to process expired surveys
  -- This requires the net extension to be enabled
  -- In production, replace with actual HTTP call to the edge function
  
  -- Simulate a successful response for now
  result := json_build_object(
    'success', true,
    'message', 'Expired survey processing triggered',
    'timestamp', now()
  );
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION trigger_expired_survey_processing() TO authenticated;