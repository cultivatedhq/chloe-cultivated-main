/*
  # Create clarity_audit_initial_sessions table

  1. New Tables
    - `clarity_audit_initial_sessions`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `name` (text)
      - `created_at` (timestamp with time zone)
  2. Security
    - Enable RLS on `clarity_audit_initial_sessions` table
    - Add policy for anonymous users to insert sessions
    - Add policy for authenticated users to read all sessions
*/

-- Create the initial sessions table
CREATE TABLE IF NOT EXISTS clarity_audit_initial_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  name text,
  created_at timestamptz DEFAULT now()
);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_clarity_audit_initial_sessions_email ON clarity_audit_initial_sessions(email);

-- Create index on created_at for sorting and cleanup
CREATE INDEX IF NOT EXISTS idx_clarity_audit_initial_sessions_created_at ON clarity_audit_initial_sessions(created_at);

-- Enable Row Level Security
ALTER TABLE clarity_audit_initial_sessions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anon users can insert initial sessions" 
  ON clarity_audit_initial_sessions
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated users can read all initial sessions" 
  ON clarity_audit_initial_sessions
  FOR SELECT
  TO authenticated
  USING (true);

-- Add foreign key to clarity_audit_results table
ALTER TABLE clarity_audit_results 
ADD COLUMN IF NOT EXISTS session_id uuid REFERENCES clarity_audit_initial_sessions(id);

-- Create index on session_id for faster joins
CREATE INDEX IF NOT EXISTS idx_clarity_audit_results_session_id ON clarity_audit_results(session_id);