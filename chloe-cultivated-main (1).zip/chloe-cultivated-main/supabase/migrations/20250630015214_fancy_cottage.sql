/*
  # Bolt Workflow Support Functions

  1. New Functions
    - `get_complete_survey_analysis`: Comprehensive analysis for a survey
    - `process_survey_completion`: Mark a survey as processed
    
  2. Purpose
    - These functions support the Bolt workflow for automated survey processing
    - They provide all the data needed for PDF report generation
    - They handle the survey completion process
*/

-- Function to mark survey as processed
CREATE OR REPLACE FUNCTION process_survey_completion(survey_id uuid)
RETURNS boolean AS $$
BEGIN
  UPDATE feedback_sessions 
  SET 
    is_active = false,
    report_generated = true,
    report_sent = true,
    report_sent_at = NOW(),
    updated_at = NOW()
  WHERE id = survey_id;
  
  RETURN FOUND;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION process_survey_completion(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION process_survey_completion(uuid) TO anon;