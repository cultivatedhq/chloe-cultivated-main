-- Get surveys that are expired and ready for report generation
SELECT 
  id,
  title,
  manager_name,
  manager_email,
  response_count,
  created_at,
  expires_at,
  is_active,
  report_generated,
  report_sent,
  report_sent_at,
  -- Calculate time since expiration
  EXTRACT(EPOCH FROM (now() - expires_at)) / 3600 as hours_since_expired,
  -- Calculate survey duration
  EXTRACT(EPOCH FROM (expires_at - created_at)) / 3600 as survey_duration_hours
FROM feedback_sessions
WHERE 
  -- Survey has expired (past the 3-day window)
  expires_at <= NOW()
  -- Report hasn't been sent yet
  AND report_sent = false
  -- Only include surveys that were active
  AND is_active = true
ORDER BY expires_at ASC;

-- Alternative query: Get surveys that need processing (more comprehensive)
SELECT 
  fs.id,
  fs.title,
  fs.manager_name,
  fs.manager_email,
  fs.response_count,
  fs.created_at,
  fs.expires_at,
  fs.is_active,
  fs.report_generated,
  fs.report_sent,
  fs.report_sent_at,
  -- Status calculation
  CASE 
    WHEN now() > fs.expires_at AND fs.report_sent = false THEN 'needs_report'
    WHEN now() > fs.expires_at AND fs.report_sent = true THEN 'completed'
    WHEN now() > (fs.expires_at - interval '24 hours') THEN 'expiring_soon'
    ELSE 'active'
  END as status,
  -- Time calculations
  EXTRACT(EPOCH FROM (now() - fs.expires_at)) / 3600 as hours_since_expired,
  EXTRACT(EPOCH FROM (fs.expires_at - now())) / 3600 as hours_until_expiry
FROM feedback_sessions fs
WHERE 
  -- Either expired and needs report, or expiring soon
  (fs.expires_at <= NOW() AND fs.report_sent = false)
  OR (fs.expires_at > NOW() AND fs.expires_at <= NOW() + interval '24 hours')
ORDER BY 
  CASE 
    WHEN fs.expires_at <= NOW() AND fs.report_sent = false THEN 1  -- Expired, needs report (highest priority)
    WHEN fs.expires_at <= NOW() + interval '24 hours' THEN 2       -- Expiring soon
    ELSE 3
  END,
  fs.expires_at ASC;

-- Query to get surveys with their response data for report generation
SELECT 
  fs.id,
  fs.title,
  fs.description,
  fs.manager_name,
  fs.manager_email,
  fs.questions,
  fs.scale_type,
  fs.response_count,
  fs.created_at,
  fs.expires_at,
  -- Aggregate response data
  COALESCE(
    json_agg(
      json_build_object(
        'responses', fr.responses,
        'comment', fr.comment,
        'submitted_at', fr.submitted_at
      ) ORDER BY fr.submitted_at
    ) FILTER (WHERE fr.id IS NOT NULL), 
    '[]'::json
  ) as responses
FROM feedback_sessions fs
LEFT JOIN feedback_responses fr ON fs.id = fr.session_id
WHERE 
  fs.expires_at <= NOW()
  AND fs.report_sent = false
  AND fs.is_active = true
GROUP BY 
  fs.id, fs.title, fs.description, fs.manager_name, fs.manager_email,
  fs.questions, fs.scale_type, fs.response_count, fs.created_at, fs.expires_at
ORDER BY fs.expires_at ASC;