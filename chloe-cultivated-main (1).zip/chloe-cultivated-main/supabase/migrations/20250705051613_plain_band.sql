/*
  # Improved Survey Analysis Function

  1. New Functions
    - `get_complete_survey_analysis_with_error_handling` - Enhanced version of the existing function with better error handling
    - Provides comprehensive survey analysis with proper error handling and logging

  2. Security
    - Function is security definer to ensure proper access control
    - Maintains existing RLS policies
*/

-- Create improved survey analysis function with better error handling
CREATE OR REPLACE FUNCTION get_complete_survey_analysis_with_error_handling(survey_id uuid)
RETURNS TABLE (
  session_data json,
  response_count bigint,
  question_analytics json,
  overall_metrics json,
  comments_data json,
  processing_status text,
  processed_at timestamptz,
  error_message text
) AS $$
DECLARE
  session_record feedback_sessions%ROWTYPE;
  scale_max integer;
  response_cnt bigint;
  err_message text;
BEGIN
  -- Get session information with error handling
  BEGIN
    SELECT * INTO session_record
    FROM feedback_sessions
    WHERE id = survey_id;
    
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Survey not found: %', survey_id;
    END IF;
  EXCEPTION WHEN OTHERS THEN
    err_message := 'Error retrieving session: ' || SQLERRM;
    RETURN QUERY
    SELECT 
      '{}'::json,
      0::bigint,
      '[]'::json,
      '{}'::json,
      '[]'::json,
      'error'::text,
      NOW(),
      err_message;
    RETURN;
  END;
  
  -- Determine scale maximum
  scale_max := CASE WHEN session_record.scale_type = 'likert_7' THEN 7 ELSE 5 END;
  
  -- Get response count with error handling
  BEGIN
    SELECT COUNT(*) INTO response_cnt
    FROM feedback_responses
    WHERE session_id = survey_id;
  EXCEPTION WHEN OTHERS THEN
    err_message := 'Error counting responses: ' || SQLERRM;
    RETURN QUERY
    SELECT 
      row_to_json(session_record)::json,
      0::bigint,
      '[]'::json,
      '{}'::json,
      '[]'::json,
      'error'::text,
      NOW(),
      err_message;
    RETURN;
  END;
  
  -- Return the complete analysis
  RETURN QUERY
  SELECT 
    -- Session data as JSON
    row_to_json(session_record)::json,
    
    -- Response count
    response_cnt,
    
    -- Question analytics as JSON with error handling
    COALESCE(
      (SELECT json_agg(
        json_build_object(
          'question_index', question_index,
          'average_score', average_score,
          'median_score', median_score,
          'total_responses', total_responses,
          'distribution', distribution
        )
      )
      FROM calculate_question_stats(survey_id, scale_max)),
      '[]'::json
    ),
    
    -- Overall metrics as JSON with error handling
    COALESCE(
      (SELECT row_to_json(metrics)
      FROM get_survey_metrics(survey_id, scale_max) metrics),
      '{}'::json
    ),
    
    -- Comments as JSON with error handling
    COALESCE(
      (SELECT json_agg(
        json_build_object(
          'comment', comment,
          'submitted_at', submitted_at
        )
      )
      FROM get_survey_comments(survey_id)),
      '[]'::json
    ),
    
    -- Processing status
    CASE 
      WHEN response_cnt > 0 THEN 'ready_for_report'
      ELSE 'no_responses'
    END,
    
    -- Processed timestamp
    NOW(),
    
    -- Error message (null if no error)
    NULL::text;
EXCEPTION WHEN OTHERS THEN
  -- Catch any other errors
  RETURN QUERY
  SELECT 
    COALESCE(row_to_json(session_record)::json, '{}'::json),
    COALESCE(response_cnt, 0),
    '[]'::json,
    '{}'::json,
    '[]'::json,
    'error'::text,
    NOW(),
    'Unexpected error: ' || SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION get_complete_survey_analysis_with_error_handling(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION get_complete_survey_analysis_with_error_handling(uuid) TO anon;

-- Create a logging function for survey processing
CREATE OR REPLACE FUNCTION log_survey_processing(
  survey_id uuid,
  status text,
  message text DEFAULT NULL
) RETURNS void AS $$
BEGIN
  -- In a production environment, you would insert into a logging table
  -- For now, we'll just raise a notice
  RAISE NOTICE 'Survey Processing Log: ID=%, Status=%, Message=%', 
    survey_id, 
    status, 
    COALESCE(message, 'No message');
END;
$$ LANGUAGE plpgsql;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION log_survey_processing(uuid, text, text) TO authenticated;