/*
  # Add User Details Columns to Clarity Audit Results

  1. New Columns Added
    - `first_name` (text) - User's first name from HubSpot form
    - `last_name` (text) - User's last name from HubSpot form  
    - `phone` (text) - User's phone number from HubSpot form
    - `company` (text) - User's company name from HubSpot form

  2. Changes Made
    - Added four new columns to store additional user information captured from HubSpot form
    - All new columns are nullable to maintain compatibility with existing records
    - Uses text data type for flexibility with various input formats

  3. Notes
    - Existing records will have NULL values for these new columns
    - New audit submissions will populate these fields from URL parameters
    - The `name` column remains for backward compatibility
*/

-- Add new columns to clarity_audit_results table
ALTER TABLE clarity_audit_results 
ADD COLUMN IF NOT EXISTS first_name text,
ADD COLUMN IF NOT EXISTS last_name text,
ADD COLUMN IF NOT EXISTS phone text,
ADD COLUMN IF NOT EXISTS company text;

-- Add indexes for better query performance on the new columns
CREATE INDEX IF NOT EXISTS idx_clarity_audit_results_first_name 
ON clarity_audit_results(first_name);

CREATE INDEX IF NOT EXISTS idx_clarity_audit_results_last_name 
ON clarity_audit_results(last_name);

CREATE INDEX IF NOT EXISTS idx_clarity_audit_results_company 
ON clarity_audit_results(company);

-- Add a comment to document the changes
COMMENT ON COLUMN clarity_audit_results.first_name IS 'User first name from HubSpot form submission';
COMMENT ON COLUMN clarity_audit_results.last_name IS 'User last name from HubSpot form submission';
COMMENT ON COLUMN clarity_audit_results.phone IS 'User phone number from HubSpot form submission';
COMMENT ON COLUMN clarity_audit_results.company IS 'User company name from HubSpot form submission';