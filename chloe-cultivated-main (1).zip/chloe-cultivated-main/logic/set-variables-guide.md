# Set Variables Guide for Bolt Workflow

After running the processing code above, use **Set Variable** blocks to define these variables:

## Required Variables:

### 1. total_responses
**Type:** Number
**Value:** `{{ processedData.total_responses }}`
**Description:** Total number of survey responses received

### 2. avg_score
**Type:** Number  
**Value:** `{{ processedData.avg_score }}`
**Description:** Average score across all Likert scale questions

### 3. avg_score_percent
**Type:** Number
**Value:** `{{ processedData.avg_score_percent }}`
**Description:** Average score as a percentage (0-100)

### 4. top_question
**Type:** String
**Value:** `{{ processedData.top_question }}`
**Description:** Text of the highest scoring question

### 5. top_score
**Type:** Number
**Value:** `{{ processedData.top_score }}`
**Description:** Score of the highest scoring question

### 6. lowest_question
**Type:** String
**Value:** `{{ processedData.lowest_question }}`
**Description:** Text of the lowest scoring question

### 7. low_score
**Type:** Number
**Value:** `{{ processedData.low_score }}`
**Description:** Score of the lowest scoring question

### 8. questions
**Type:** Array
**Value:** `{{ processedData.questions }}`
**Description:** Array of question objects with text, avg, median, and distribution

### 9. open_text_responses
**Type:** Array
**Value:** `{{ processedData.open_text_responses }}`
**Description:** Array of responses to the Start/Stop/Keep question

### 10. additional_comments
**Type:** Array
**Value:** `{{ processedData.additional_comments }}`
**Description:** Array of additional comments from respondents

## Usage in Bolt Workflow:

1. **Logic Block:** Use the JavaScript code above to process the raw survey data
2. **Set Variable Blocks:** Create individual Set Variable blocks for each variable listed above
3. **Use Variables:** Reference these variables in subsequent blocks (email templates, PDF generation, etc.)

## Example Email Template Usage:

```
Survey Results Summary:
- Total Responses: {{ total_responses }}
- Overall Score: {{ avg_score_percent }}%
- Strongest Area: {{ top_question }} ({{ top_score }})
- Development Area: {{ lowest_question }} ({{ low_score }})

Start/Stop/Keep Feedback:
{{ open_text_responses.join('\n\n') }}

Additional Comments:
{{ additional_comments.join('\n\n') }}
```

## Data Structure for questions variable:

Each question object contains:
```javascript
{
  text: "Question text",
  avg: 4.2,           // Average score
  median: 4.0,        // Median score  
  dist: {             // Response distribution
    1: 0,             // Number of 1-star responses
    2: 1,             // Number of 2-star responses
    3: 2,             // Number of 3-star responses
    4: 3,             // Number of 4-star responses
    5: 2              // Number of 5-star responses
  }
}
```