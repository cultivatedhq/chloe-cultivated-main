# Survey Processing Logic Steps

## For Each Survey Loop Implementation

### Step 1: Get Responses for That Survey
```sql
-- Input: survey.id from the loop
-- Output: responses array

SELECT * FROM feedback_responses
WHERE session_id = {{ survey.id }};
```

### Step 2: Process & Analyze Data

#### Count Total Responses
```javascript
// Logic block to count responses
const totalResponses = responses.length;
```

#### Calculate Average, Median, Distribution
```javascript
// For each question in the survey
const questionAnalytics = [];

for (let questionIndex = 0; questionIndex < survey.questions.length; questionIndex++) {
  const questionResponses = responses
    .map(r => r.responses[questionIndex])
    .filter(r => r > 0 && r <= scaleMax);
  
  if (questionResponses.length > 0) {
    // Calculate average
    const average = questionResponses.reduce((sum, val) => sum + val, 0) / questionResponses.length;
    
    // Calculate median
    const sorted = [...questionResponses].sort((a, b) => a - b);
    const median = sorted.length % 2 === 0
      ? (sorted[Math.floor(sorted.length / 2) - 1] + sorted[Math.floor(sorted.length / 2)]) / 2
      : sorted[Math.floor(sorted.length / 2)];
    
    // Calculate distribution
    const distribution = {};
    questionResponses.forEach(response => {
      distribution[response] = (distribution[response] || 0) + 1;
    });
    
    questionAnalytics.push({
      questionIndex,
      questionText: survey.questions[questionIndex],
      average: Math.round(average * 100) / 100,
      median,
      distribution,
      responseCount: questionResponses.length
    });
  }
}
```

#### Find Strongest and Lowest Scoring Questions
```javascript
// Find highest scoring question
const highestScoring = questionAnalytics.reduce((max, current) => 
  current.average > max.average ? current : max
);

// Find lowest scoring question  
const lowestScoring = questionAnalytics.reduce((min, current) => 
  current.average < min.average ? current : min
);
```

#### Count Comments
```javascript
// Count and collect comments
const comments = responses
  .map(r => r.comment)
  .filter(comment => comment && comment.trim().length > 0);

const commentCount = comments.length;
```

### Step 3: Generate Report Data Structure
```javascript
const reportData = {
  session: {
    id: survey.id,
    title: survey.title,
    manager_name: survey.manager_name,
    manager_email: survey.manager_email,
    questions: survey.questions,
    scale_type: survey.scale_type,
    response_count: totalResponses,
    created_at: survey.created_at,
    expires_at: survey.expires_at,
    description: survey.description
  },
  analytics: {
    total_responses: totalResponses,
    question_analytics: questionAnalytics,
    overall_average: questionAnalytics.reduce((sum, q) => sum + q.average, 0) / questionAnalytics.length,
    highest_scoring_question: highestScoring,
    lowest_scoring_question: lowestScoring,
    comments: comments,
    comment_count: commentCount,
    completion_rate: totalResponses > 0 ? 100 : 0,
    performance_category: getPerformanceCategory(overallAverage, scaleMax)
  }
};
```

### Step 4: Determine Next Actions
```javascript
// Determine what to do with this survey
if (totalResponses > 0) {
  // Generate and send PDF report
  await generatePDFReport(reportData);
  await sendReportEmail(survey.manager_email, reportData);
  
  // Update survey status
  await updateSurveyStatus(survey.id, {
    is_active: false,
    report_generated: true,
    report_sent: true,
    report_sent_at: new Date()
  });
  
  console.log(`✅ Report generated for survey: ${survey.title}`);
} else {
  // Send no-responses notification
  await sendNoResponsesEmail(survey.manager_email, survey);
  
  // Update survey status
  await updateSurveyStatus(survey.id, {
    is_active: false,
    report_generated: true,
    report_sent: true,
    report_sent_at: new Date()
  });
  
  console.log(`📭 No responses notification sent for: ${survey.title}`);
}
```

## Helper Functions

### Performance Category Classification
```javascript
function getPerformanceCategory(averageScore, scaleMax) {
  const percentage = (averageScore / scaleMax) * 100;
  
  if (percentage >= 80) return 'excellent';
  if (percentage >= 60) return 'good';
  if (percentage >= 40) return 'fair';
  return 'needs_improvement';
}
```

### Scale Maximum Determination
```javascript
function getScaleMax(scaleType) {
  return scaleType === 'likert_7' ? 7 : 5;
}
```

## Error Handling
```javascript
try {
  // Process survey
  await processSurvey(survey);
} catch (error) {
  console.error(`❌ Error processing survey ${survey.id}:`, error);
  
  // Log error but continue with next survey
  await logProcessingError(survey.id, error.message);
}
```